
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
try:
    _runtime_version.ValidateProtobufRuntimeVersion(
        _runtime_version.Domain.PUBLIC,
        7,
        35,
        1,
        '',
        'StartMatch.proto'
    )
except Exception:
    pass
                                   

_sym_db = _symbol_database.Default()




DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x10StartMatch.proto\"\xec\x01\n\rStartUDPMatch\x12$\n\x04main\x18\x02 \x01(\x0b\x32\x16.StartUDPMatch.nested1\x1a\xb4\x01\n\x07nested1\x12\x33\n\x0bregion_list\x18\x07 \x03(\x0b\x32\x1e.StartUDPMatch.nested1.nested2\x12\x36\n\x0e\x63lient_version\x18\x0c \x01(\x0b\x32\x1e.StartUDPMatch.nested1.nested3\x1a\x19\n\x07nested2\x12\x0e\n\x06region\x18\x03 \x01(\t\x1a!\n\x07nested3\x12\x16\n\x0eremote_version\x18\x08 \x01(\tb\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'StartMatch_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
  DESCRIPTOR._loaded_options = None
  _globals['_STARTUDPMATCH']._serialized_start=21
  _globals['_STARTUDPMATCH']._serialized_end=257
  _globals['_STARTUDPMATCH_NESTED1']._serialized_start=77
  _globals['_STARTUDPMATCH_NESTED1']._serialized_end=257
  _globals['_STARTUDPMATCH_NESTED1_NESTED2']._serialized_start=197
  _globals['_STARTUDPMATCH_NESTED1_NESTED2']._serialized_end=222
  _globals['_STARTUDPMATCH_NESTED1_NESTED3']._serialized_start=224
  _globals['_STARTUDPMATCH_NESTED1_NESTED3']._serialized_end=257
                                        

                                                                          
                                                                          
                                                                          